<template>
  <div>
    <div class="table-toolbar" v-if="showToolbar">
      <div class="table-title">{{ title }}</div>
      <div class="table-actions">
        <slot name="toolbar" />
      </div>
    </div>

    <el-table
      :data="items"
      border
      stripe
      style="width: 100%"
      max-height="520"
      @row-dblclick="emitRowDetail"
    >
      <el-table-column
        v-for="column in columns"
        :key="column"
        :prop="column"
        :label="column"
        min-width="140"
        show-overflow-tooltip
      >
        <template #default="scope">
          {{ formatCell(scope.row[column]) }}
        </template>
      </el-table-column>

      <el-table-column v-if="items.length" label="操作" width="100" fixed="right">
        <template #default="scope">
          <el-button link type="primary" @click="emitRowDetail(scope.row)">
            查看
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

interface Props {
  items: Record<string, any>[]
  title?: string
  showToolbar?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  title: '结果表格',
  showToolbar: true,
})

const emit = defineEmits<{
  (e: 'row-detail', row: Record<string, any>): void
}>()

/**
 * 推断表格列。
 * 说明：
 * 第二版不再只取第一行字段，而是把所有行的字段做并集，
 * 再按字母顺序排序，保证表头稳定。
 */
const columns = computed(() => {
  const set = new Set<string>()
  for (const item of props.items || []) {
    Object.keys(item || {}).forEach((key) => set.add(key))
  }
  return Array.from(set).sort()
})

/**
 * 格式化单元格内容。
 * 说明：
 * 1. 空值统一显示为短横线；
 * 2. 数字和纯数字字符串统一格式化为千分位；
 * 3. 对象与数组统一转 JSON 文本。
 */
function formatCell(value: unknown) {
  if (value === null || value === undefined || value === '') return '-'

  if (typeof value === 'number') {
    return value.toLocaleString()
  }

  if (typeof value === 'string') {
    const trimmed = value.trim()
    if (/^-?\d+(\.\d+)?$/.test(trimmed)) {
      const num = Number(trimmed)
      if (!Number.isNaN(num)) return num.toLocaleString()
    }
    return value
  }

  if (Array.isArray(value) || typeof value === 'object') {
    return JSON.stringify(value)
  }

  return String(value)
}

/**
 * 触发行明细查看。
 */
function emitRowDetail(row: Record<string, any>) {
  emit('row-detail', row)
}
</script>

<style scoped>
.table-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}
.table-title {
  font-weight: 600;
}
.table-actions {
  display: flex;
  gap: 8px;
}
</style>
