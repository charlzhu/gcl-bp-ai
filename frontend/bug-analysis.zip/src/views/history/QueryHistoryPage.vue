<template>
  <div class="page-card">
    <div class="page-header">
      <div>
        <h2 class="page-title">查询历史</h2>
        <p class="page-subtitle">
          查看已落库的查询记录，便于回溯模板命中、执行模式和原始问题。
        </p>
      </div>
      <el-space>
        <el-button type="primary" :loading="loading" @click="load">刷新</el-button>
      </el-space>
    </div>

    <el-alert
      v-if="loadError"
      :title="loadError"
      type="warning"
      :closable="false"
      show-icon
      style="margin-bottom: 16px"
    />

    <el-table :data="list" border stripe>
      <el-table-column prop="question" label="问题" min-width="220" />
      <el-table-column prop="execution_mode" label="执行模式" width="120" />
      <el-table-column prop="status" label="状态" width="120" />
      <el-table-column prop="created_at" label="时间" min-width="180" />
      <el-table-column label="操作" width="120" fixed="right">
        <template #default="scope">
          <el-button size="small" @click="view(scope.row)">查看</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog v-model="visible" title="查询详情" width="65%">
      <div class="mono-block">{{ formatJson(current) }}</div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { fetchQueryHistory } from '@/api/logistics'

const list = ref<Record<string, any>[]>([])
const visible = ref(false)
const current = ref<Record<string, any> | null>(null)
const loading = ref(false)
const loadError = ref('')

/**
 * 加载查询历史。
 * 说明：
 * 如果当前后端还没有开放该接口，这里会显示友好提示，不影响页面其它功能。
 */
async function load() {
  loading.value = true
  loadError.value = ''
  try {
    const resp = await fetchQueryHistory()
    list.value = resp.data ?? resp ?? []
  } catch (_error) {
    loadError.value = '当前后端未开放查询历史接口，或接口路径与前端默认配置不一致。'
    list.value = []
  } finally {
    loading.value = false
  }
}

/**
 * 查看单条历史记录。
 */
function view(row: Record<string, any>) {
  current.value = row
  visible.value = true
}

/**
 * JSON 格式化。
 */
function formatJson(value: unknown) {
  if (!value) return '-'
  return JSON.stringify(value, null, 2)
}

onMounted(() => {
  load()
})
</script>

<style scoped>
.page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}
</style>
